﻿using System;

namespace DownloaderModel
{
    public class Class1
    {
    }
}
