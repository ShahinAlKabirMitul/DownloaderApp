﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DownloaderApp.WPF
{
   public interface IWindowFactory
    {
        void CreateNewWindow();
    }
}
