﻿using DownloaderModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace DownloadApp.Service
{
  public  interface IUserService
    {
        List<User> GetUsers();
    }
}
