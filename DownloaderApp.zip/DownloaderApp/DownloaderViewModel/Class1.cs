﻿using System;

namespace DownloaderViewModel
{
    public class Class1
    {
    }
}
