﻿using DownloaderModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;

namespace DownloadApp.Service
{
  public  class UserService: IUserService
    {
       
    }
}
