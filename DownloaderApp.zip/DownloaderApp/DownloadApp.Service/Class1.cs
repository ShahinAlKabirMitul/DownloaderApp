﻿using System;

namespace DownloadApp.Service
{
    public class Class1
    {
    }
}
